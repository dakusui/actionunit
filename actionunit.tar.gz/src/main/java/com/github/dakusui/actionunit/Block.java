package com.github.dakusui.actionunit;

import com.google.common.base.Function;

public interface Block<T> extends Function<T, Void> {

}
