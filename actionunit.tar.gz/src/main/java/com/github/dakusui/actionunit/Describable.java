package com.github.dakusui.actionunit;

public interface Describable {
  String describe();
}
